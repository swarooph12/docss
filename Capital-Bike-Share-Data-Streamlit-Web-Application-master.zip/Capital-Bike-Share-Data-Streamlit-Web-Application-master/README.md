# Capital-Bike-Share-Data-Streamlit-Web-Application
It is a web app tutorial project made with streamlit, a ML web app tool. It has some super cool features that can eliminate the need of any web framework. So, a data scientist can focus entirely on the analytics part rather than worrying about managing frontend and backend with any sort of framework. Do check out this project!

How to run the project?
Change directory to your current directory and type command in terminal/cmd:-

streamlit run demoStreamlit.py

Note: You need to install all the libraries that are imported in demoStreamlit.py in order to succeesfully run the project.
